import React from 'react'

// rafce
const Header = () => {
  return (
    <>
      <h1>Igrica</h1>
      <p>Pronadji reč, unesi slovo!</p>
    </> 
  )
}

export default Header
